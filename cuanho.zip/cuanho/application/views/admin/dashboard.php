<div class="container">
  <h2 class="text-center font-weight-bold">PROFILE KAMI</h2>
  <div class="row ml-3 mr-3">
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <img class="card-img-top" src="<?php echo base_url('assets/img/dd1.jpg') ?>" alt="">
        <h5 class="card-title mt-2 font-weight-bold">Dhyte Nugrahanto</h5>
        <p class="card-text">NIM : 19.01.4425</p>
        <p class="card-text">PRODI : D3 Teknik Informatika 03</p>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <img class="card-img-top" src="<?php echo base_url('assets/img/gusty.jpg') ?>" alt="">
        <h5 class="card-title mt-2 font-weight-bold">Gabriel Kreshna Gusty</h5>
        <p class="card-text">NIM : 19.01.4401</p>
        <p class="card-text">PRODI : D3 Teknik Informatika 03</p>
      </div>
    </div>
  </div>
</div>
</div>